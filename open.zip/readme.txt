# 🎵 LYRICODE — AI Song → ESP32 OLED Lyric Display

**Turn ANY song into a word-by-word synced OLED lyric visualizer.**
No manual timing. No guesswork. AI does everything.

---

## ✨ What It Does

1. **Separates vocals** from music (Meta Demucs)
2. **Detects vocal regions** (Silero VAD)
3. **Aligns every lyric word** to exact millisecond timestamps (WhisperX)
4. **Snaps word boundaries** to real vocal onsets (Librosa DSP)
5. **Generates ready-to-flash ESP32 code** with 4 animation themes

### Smart Features
- ✂️ **Auto-trim:** songs longer than 1:30 are cut to 90s, lyrics cut to match
- 🔥 **FIRE MODE:** non-English lyrics (Japanese/Hindi/etc.) → no lyrics, just fire + animation
- 🎛 **Live nudge:** TAP button = 0.5s later, HOLD = 0.5s earlier
- 📁 **Per-song folders:** every song saves into `songs/<name>/`
- 🧠 **Auto animation suggestion** based on song tempo (words/min)

---

## 📦 Project Structure

```
LYRICODE/
├── lyricode.py        ← ONE-COMMAND pipeline (recommended)
├── main.py            ← CLI decoder
├── core.py            ← AI engine (Demucs + VAD + WhisperX + DSP)
├── refine.py          ← onset snapping + stretch/pause fixing
├── generate_ino.py    ← ESP32 code generator
├── make_zip.py        ← builds LYRICODE_release.zip
├── README.md          ← this file (ALL instructions)
└── sample_songs/      ← your 4 demo songs (mp3 + lyrics txt)
```

---

## 🔧 Hardware

| Item | Details |
|------|---------|
| ESP32 Dev Board | Any |
| OLED | 0.96" SSD1306 (I2C) |

### Wiring

| OLED | ESP32 |
|------|-------|
| VCC | 3.3V |
| GND | GND |
| SCL | GPIO 22 |
| SDA | GPIO 21 |

---

## 💻 INSTALL — ALL COMMANDS

### 1. Python libraries (ONE command)
```
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu118 && pip install demucs librosa soundfile numpy whisperx faster-whisper
```

### 2. FFmpeg (if missing)
```
winget install --id Gyan.FFmpeg -e
```

### 3. Arduino libraries (Library Manager)
Install these two in Arduino IDE → *Sketch → Include Library → Manage Libraries*:
```
Adafruit SSD1306
Adafruit GFX Library
```

---

## ▶️ USAGE

### 🥇 ONE COMMAND (recommended)
Put your song (`.mp3`) and lyrics (`.txt`) in the folder, then:
```
python lyricode.py
```
It will automatically:
1. Ask the **song name** (creates `songs/<name>/` subfolder)
2. Pick your **audio** + **lyrics** file
3. 🧹 Clear old cache
4. ✂️ Trim songs >1:30 to 90s (lyrics cut to match)
5. 🔥 Detect non-English → FIRE MODE
6. Decode → Refine → suggest animation (⭐ recommended)
7. Generate `songs/<name>/lyricode_<name>.ino`

### 🥈 Manual pipeline (optional)
```
python main.py --audio song.mp3 --lyrics lyrics.txt
python refine.py
python generate_ino.py
```

### 📦 Build the release ZIP
```
python make_zip.py
```

---

## 🎨 Animation Themes

| # | Name | Background | Best For |
|---|------|-----------|----------|
| 1 | 🔥 ENERGY | Tunnel + EQ Bars + Shockwaves | Pop / Dance |
| 2 | 🌊 CHILL | Stars + Wave | Slow / Acoustic |
| 3 | ⚡ GLITCH | Matrix Rain + Shockwaves | Rap / Fast / EDM |
| 4 | 💫 DREAMY | Bubbles + Pulse Rings | R&B / Ballad |

---

## 🕹️ On The Hardware

1. Flash the generated `.ino` in Arduino IDE
2. OLED shows: **"PLAY SAME MP3, PRESS BOOT ON FIRST WORD"**
3. Start the **same MP3** you decoded on your phone/speaker
4. Press **BOOT** exactly when you hear the **first word**
5. Live fix while playing: **TAP** = 0.5s later · **HOLD** = 0.5s earlier

---

## 🛠️ TROUBLESHOOTING

| Problem | Fix |
|---------|-----|
| Wrong song's vocals used | `rmdir /s /q stems` then re-run |
| `Decoded 0 words` / `backtrack failed` | Song too long → use `lyricode.py` (auto-trims to 90s) |
| Huge lyrics | Auto-capped at 600 words |
| Words switch too fast on stretches | `refine.py` holds each word until the next starts |
| Non-English lyrics | Automatic 🔥 FIRE MODE |
| `drawCircle ... expects 4 arguments` | Run `fix_white.py` (adds missing `, WHITE`) |
| `has no member named drawVLine` | Run `fix2.py` (renames to `drawFastVLine`) |
| `IndexError: list index out of range` | JSON empty → re-run `main.py` + `refine.py` |

---

## 📤 Publish To GitHub

```
git init
git add .
git commit -m "LYRICODE - AI Song to ESP32 OLED Lyric Display"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/song-decoder.git
git push -u origin main
```

### `.gitignore` (don't upload heavy files)
```
stems/
uploads/
__pycache__/
*.pyc
*.mp3
*.wav
*.flac
*.m4a
output/
songs/
venv/
.DS_Store
Thumbs.db
```

---

## 🙏 Credits
Demucs (Meta AI) · WhisperX · Silero VAD · Librosa · Adafruit GFX/SSD1306

**Free to use, modify and share.** Built with ❤️ for the maker community.