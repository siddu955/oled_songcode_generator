import os
import subprocess
import json
import torch
import librosa
import numpy as np
import whisperx
import soundfile as sf

# ─── SAFETY LIMIT: max words fed to the aligner in one pass ───
# Wav2Vec2 crashes ("backtrack failed") on huge lyric sheets.
# If a song has more words than this, we trim and ignore the rest.
# Lower it (e.g. 300 / 250) if some song still crashes.
MAX_ALIGN_WORDS = 350

class SongDecoder:
    def __init__(self, device="cuda" if torch.cuda.is_available() else "cpu"):
        self.device = device
        self.compute_type = "float16" if device == "cuda" else "int8"
        print(f"[INIT] Decoder ready on {self.device.upper()}")

    def separate_vocals(self, audio_path, output_dir="stems"):
        filename = os.path.splitext(os.path.basename(audio_path))[0]
        vocal_path = os.path.join(output_dir, "htdemucs", filename, "vocals.wav")
        
        # CACHE FIX: Only skip if the vocal file is NEWER than the audio file
        if os.path.exists(vocal_path) and os.path.getmtime(vocal_path) > os.path.getmtime(audio_path):
            print(f"[1/4] Vocals found in cache. Skipping separation.")
            return vocal_path

        print("[1/4] Separating vocals using Demucs...")
        os.makedirs(output_dir, exist_ok=True)
        cmd = ["python", "-m", "demucs", "--two-stems", "vocals", "-n", "htdemucs", "--out", output_dir, audio_path]
        subprocess.run(cmd, check=True)
        return vocal_path

    def detect_vad(self, vocal_path):
        print("[2/4] Detecting vocal regions...")
        try:
            model, utils = torch.hub.load('snakers4/silero-vad', 'silero_vad', trust_repo=True)
            (get_speech_timestamps, _, read_audio, _, _) = utils
            wav = read_audio(vocal_path, sampling_rate=16000)
            speech_timestamps = get_speech_timestamps(wav, model, sampling_rate=16000)
            regions = [(ts['start'] / 16000, ts['end'] / 16000) for ts in speech_timestamps]
            print(f"   -> Found {len(regions)} vocal regions.")
            return regions
        except Exception as e:
            print(f"   [!] VAD Error: {e}")
            return [(0, librosa.get_duration(path=vocal_path))]

    def align_lyrics(self, vocal_path, lyrics_text, vad_regions):
        print("[3/4] Aligning full song lyrics...")
        clean_text = " ".join(lyrics_text.split())

        # 🚨 TRIM FIX: cut huge lyrics below the crash limit, ignore the rest
        word_list = clean_text.split()
        if len(word_list) > MAX_ALIGN_WORDS:
            print(f"   ⚠️ Lyrics too huge ({len(word_list)} words).")
            print(f"   ✂️ Trimming to {MAX_ALIGN_WORDS} words to avoid crash (rest ignored).")
            clean_text = " ".join(word_list[:MAX_ALIGN_WORDS])

        audio = whisperx.load_audio(vocal_path)
        duration = len(audio) / 16000
        
        first_start = vad_regions[0][0] if vad_regions else 0
        last_end = vad_regions[-1][1] if vad_regions else duration
        
        # The original working line (no base.en, no chunking)
        model_a, metadata = whisperx.load_align_model(language_code="en", device=self.device)
        
        segments = [{"text": clean_text, "start": first_start, "end": last_end}]
        
        result = whisperx.align(segments, model_a, metadata, audio, self.device, return_char_alignments=False)
        
        words = []
        if result and "segments" in result:
            for seg in result["segments"]:
                if "words" in seg:
                    words.extend(seg["words"])
        return words

    def refine_boundaries_dsp(self, vocal_path, words):
        print("[4/4] Refining to exact milliseconds...")
        y, sr = librosa.load(vocal_path, sr=16000)
        rms = librosa.feature.rms(y=y)[0]
        times = librosa.times_like(rms, sr=sr)
        
        refined = []
        for w in words:
            if not w.get("word"): continue
            start_s, end_s = w.get("start", 0), w.get("end", 0)
            
            start_idx = np.argmin(np.abs(times - start_s))
            search_window = rms[max(0, start_idx-10):start_idx+10]
            if len(search_window) > 0:
                spikes = np.where(search_window > np.max(search_window) * 0.2)[0]
                if len(spikes) > 0:
                    start_s = times[max(0, start_idx-10) + spikes[0]]
            
            end_idx = np.argmin(np.abs(times - end_s))
            search_window_end = rms[max(0, end_idx-5):end_idx+15]
            if len(search_window_end) > 0:
                drops = np.where(search_window_end < np.max(search_window_end) * 0.15)[0]
                if len(drops) > 0:
                    end_s = times[max(0, end_idx-5) + drops[0]]
            
            if end_s <= start_s: end_s = start_s + 0.1
            
            refined.append({
                "word": w["word"].strip(),
                "start_ms": int(start_s * 1000),
                "end_ms": int(end_s * 1000),
                "confidence": round(w.get("score", 0.9), 3)
            })
        return refined

    def decode(self, audio_path, lyrics_path, output_json="output.json"):
        print(f"=== DECODING FULL SONG: {os.path.basename(audio_path)} ===")
        
        with open(lyrics_path, 'r', encoding='utf-8') as f:
            lyrics_text = f.read()
            
        vocal_path = self.separate_vocals(audio_path)
        vad_regions = self.detect_vad(vocal_path)
        raw_words = self.align_lyrics(vocal_path, lyrics_text, vad_regions)
        final_words = self.refine_boundaries_dsp(vocal_path, raw_words)
        
        output_data = {
            "song": os.path.basename(audio_path),
            "total_duration_ms": int(librosa.get_duration(path=vocal_path) * 1000),
            "words": final_words
        }
        
        os.makedirs(os.path.dirname(output_json) or '.', exist_ok=True)
        
        with open(output_json, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2)
            
        print(f"\n[SUCCESS] Decoded {len(final_words)} words.")
        print(f"[OUTPUT] {output_json}")
        return output_data
