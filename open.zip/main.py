import argparse
import os
from core import SongDecoder

def main():
    parser = argparse.ArgumentParser(description="Professional Song Decoder")
    parser.add_argument("--audio", required=True, help="Path to song (mp3, wav)")
    parser.add_argument("--lyrics", required=True, help="Path to lyrics.txt")
    parser.add_argument("--output", default="decoded_lyrics.json", help="Output JSON filename")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.audio):
        print(f"[ERROR] Audio file not found: {args.audio}")
        return
    if not os.path.exists(args.lyrics):
        print(f"[ERROR] Lyrics file not found: {args.lyrics}")
        return

    try:
        decoder = SongDecoder()
        decoder.decode(args.audio, args.lyrics, args.output)
    except Exception as e:
        print(f"[FATAL ERROR] {e}")

if __name__ == "__main__":
    main()
