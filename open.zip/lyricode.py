import os, sys, glob, json, shutil, re
import librosa
import numpy as np
import soundfile as sf

MAX_WORDS = 600
MAX_DURATION_SEC = 90

# Detect non-English scripts (Japanese, Chinese, Korean, Hindi, Thai, Cyrillic)
NON_ENGLISH = re.compile(r'[\u0900-\u097F\u0E00-\u0E7F\u3000-\u30FF\u4E00-\u9FFF\uAC00-\uD7AF\u0400-\u04FF]')

CPP_TEMPLATE = """
/* LYRICODE :: __SONG_NAME__ | THEME __THEME__ | LYRICS __HAS_LYRICS__ */
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SYNC_BUTTON_PIN 0
#define THEME __THEME__
#define HAS_LYRICS __HAS_LYRICS__

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define NUM_CIRCLES 5
float circleRadii[NUM_CIRCLES];
#define NUM_BARS 12
int barHeights[NUM_BARS]; int targetHeights[NUM_BARS];
struct Shockwave { float radius; bool active; } wave;
int starX[30], starY[30], starS[30]; float wavePhase=0;
int dropY[16], dropL[16], dropS[16];
int bubX[10], bubY[10], bubR[10], bubS[10]; float pulsePhase=0;
int lastLyricIdx = -1; unsigned long frameCount = 0;

enum Effect { EFFECT_NONE=0, EFFECT_POP, EFFECT_SHAKE, EFFECT_INVERT,
  EFFECT_GLITCH, EFFECT_ZOOM_IN, EFFECT_FLOAT, EFFECT_PULSE, EFFECT_SLOW_ZOOM };

struct Lyric { unsigned long startMs; unsigned long durationMs; char word[24]; Effect effect; uint8_t size; };

const Lyric lyrics[] PROGMEM = {
__LYRICS_DATA__
};
const int numLyrics = sizeof(lyrics)/sizeof(Lyric);
unsigned long TOTAL_LOOP_TIME = __TOTAL_DURATION__;
unsigned long startTime = 0; bool synced = false;
int lyricSearchStart = 0; long syncOffset = 0;
bool btnWas = false; unsigned long btnDownAt = 0;

void handleNudge() {
  bool pressed = digitalRead(SYNC_BUTTON_PIN) == LOW;
  if (pressed && !btnWas) { btnWas = true; btnDownAt = millis(); }
  else if (!pressed && btnWas) {
    btnWas = false;
    if (millis() - btnDownAt < 300) syncOffset -= 500; else syncOffset += 500;
  }
}

int findCurrentLyric(unsigned long now) {
  for (int i = lyricSearchStart; i < numLyrics; i++) {
    Lyric l; memcpy_P(&l, &lyrics[i], sizeof(Lyric));
    if (now >= l.startMs && now <= (l.startMs + l.durationMs)) { lyricSearchStart = i; return i; }
    if (now > l.startMs + l.durationMs) lyricSearchStart = i + 1;
  }
  return -1;
}

void setup() {
  Serial.begin(115200); Wire.begin(); Wire.setClock(800000);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) for (;;);
  display.clearDisplay(); display.setTextColor(WHITE); display.setTextWrap(false);
  randomSeed(analogRead(34));
  for (int i=0;i<NUM_CIRCLES;i++) circleRadii[i]=i*(100.0/NUM_CIRCLES);
  for (int i=0;i<NUM_BARS;i++){barHeights[i]=0;targetHeights[i]=0;}
  for (int i=0;i<30;i++){starX[i]=random(128);starY[i]=random(50);starS[i]=random(1,3);}
  for (int i=0;i<16;i++){dropY[i]=random(-30,64);dropL[i]=random(6,18);dropS[i]=random(1,3);}
  for (int i=0;i<10;i++){bubX[i]=random(4,124);bubY[i]=random(80);bubR[i]=random(2,5);bubS[i]=random(1,3);}
  wave.active=false; pinMode(SYNC_BUTTON_PIN, INPUT_PULLUP);
  display.setTextSize(1);
  display.setCursor(5,8);  display.print("__SONG_NAME__");
  display.setCursor(5,22); display.print("PLAY SAME MP3,");
  display.setCursor(5,32); display.print("PRESS BOOT ON");
  display.setCursor(5,42); display.print("__BOOT_LINE__");
  display.setCursor(5,54); display.print("TAP/HOLD=NUDGE");
  display.display();
  while (digitalRead(SYNC_BUTTON_PIN)==HIGH) delay(10);
  delay(50);
  while (digitalRead(SYNC_BUTTON_PIN)==LOW) delay(10);
  startTime = millis(); synced = true; btnWas = false;
}

void loop() {
  if (!synced) return;
  handleNudge();
  long nowL = (long)(millis()-startTime) + syncOffset; if (nowL<0) nowL=0;
  unsigned long now = (unsigned long)nowL; frameCount++;
  if (now > TOTAL_LOOP_TIME) { display.clearDisplay(); display.setTextSize(2); display.setCursor(20,24); display.print("THE END"); display.display(); delay(100); return; }
  display.clearDisplay(); display.setTextSize(1);
  int idx = HAS_LYRICS ? findCurrentLyric(now) : -1;
  Effect cur = EFFECT_NONE; bool act = false; float prog = 0; bool inv = false;
  if (idx != -1) {
    act = true; Lyric l; memcpy_P(&l, &lyrics[idx], sizeof(Lyric));
    cur = l.effect; prog = (now - l.startMs)/(float)l.durationMs;
    if (idx != lastLyricIdx) {
      if (cur==EFFECT_POP||cur==EFFECT_INVERT||cur==EFFECT_ZOOM_IN||cur==EFFECT_SHAKE){wave.active=true;wave.radius=5;}
      lastLyricIdx = idx;
    }
  } else lastLyricIdx = -1;

  if (frameCount % 2 == 0) {
    if (THEME==1) drawTunnel(cur, act);
    else if (THEME==2) drawStars();
    else if (THEME==3) drawMatrix();
    else drawBubbles();
  }
  if (HAS_LYRICS) {
    if (THEME==1) drawEQ(cur, act);
    if (THEME==1 || THEME==3) drawShockwave();
  } else {
    drawFire();
  }

  if (HAS_LYRICS && idx != -1) {
    Lyric l; memcpy_P(&l, &lyrics[idx], sizeof(Lyric));
    int ts = l.size, ox=0, oy=0;
    if (l.effect==EFFECT_POP){ if(prog<0.15) ts=l.size+1; }
    else if (l.effect==EFFECT_SHAKE){ ox=random(-1,2); oy=random(-1,2); }
    else if (l.effect==EFFECT_INVERT){ inv=true; if(random(10)>5){ox=random(-2,3);oy=random(-2,3);} }
    else if (l.effect==EFFECT_GLITCH){ if(random(10)>6){ox=random(-6,6);display.fillRect(0,random(SCREEN_HEIGHT),SCREEN_WIDTH,random(2,8),WHITE);} if(random(10)>8)inv=true; }
    else if (l.effect==EFFECT_ZOOM_IN){ if(prog<0.05)ts=l.size>1?l.size-1:1; else if(prog<0.1)ts=l.size; else ts=l.size+1; if(prog>0.4){ox=random(-4,5);oy=random(-4,5);} if(prog>0.3&&random(10)>7)inv=true; }
    else if (l.effect==EFFECT_FLOAT){ oy=-sin(prog*3.14159)*6+random(-1,2); ox=random(-1,2); }
    else if (l.effect==EFFECT_PULSE){ if((prog>0.1&&prog<0.25)||(prog>0.6&&prog<0.75))ts=l.size+1; ox=random(-1,2); oy=random(-1,2); }
    else if (l.effect==EFFECT_SLOW_ZOOM){ oy=-(prog*5)+random(-1,2); ox=random(-1,2); if(prog>0.5)ts=l.size+1; }
    display.setTextSize(ts);
    int16_t x1,y1; uint16_t w,h;
    display.getTextBounds(l.word,0,0,&x1,&y1,&w,&h);
    if (w>SCREEN_WIDTH){ts=2;display.setTextSize(2);display.getTextBounds(l.word,0,0,&x1,&y1,&w,&h);}
    if (w>SCREEN_WIDTH){ts=1;display.setTextSize(1);display.getTextBounds(l.word,0,0,&x1,&y1,&w,&h);}
    int dx=(SCREEN_WIDTH-w)/2+ox, dy=(SCREEN_HEIGHT-h)/2+oy-5;
    int bx=dx-6,by=dy-5,bw=w+12,bh=h+10;
    if(bx<0){bw+=bx;bx=0;} if(bx+bw>SCREEN_WIDTH)bw=SCREEN_WIDTH-bx;
    display.fillRoundRect(bx,by,bw,bh,3,BLACK);
    display.drawRoundRect(bx,by,bw,bh,3,WHITE);
    if (l.effect==EFFECT_GLITCH && random(10)>8){ display.setTextColor(BLACK,WHITE); display.fillRoundRect(dx-4,dy-3,w+8,h+6,2,WHITE); }
    else display.setTextColor(WHITE);
    display.setCursor(dx,dy); display.print(l.word);
  }
  display.invertDisplay(inv); display.display(); delay(5);
}

void drawFire() {
  int cx=64, cy=42;
  for (int i=0;i<6;i++) {
    int r = 10 - i*2 + random(-1,1);
    if (r>1) display.drawCircle(cx+random(-1,1), cy-i*3, r, WHITE);
  }
  display.fillCircle(cx, cy-4, 2+random(0,1), WHITE);
  for (int i=0;i<5;i++) display.drawPixel(cx+random(-8,9), cy-random(4,28), WHITE);
}
void drawTunnel(Effect c, bool a) {
  float sp=1.0; if(c==EFFECT_ZOOM_IN)sp=8; else if(c==EFFECT_SHAKE||c==EFFECT_GLITCH)sp=4; else if(!a)sp=0.5;
  int cx=64,cy=32; if(c==EFFECT_SHAKE||c==EFFECT_ZOOM_IN){cx+=random(-3,4);cy+=random(-3,4);}
  for(float an=0;an<2*PI;an+=PI/2) display.drawLine(cx+cos(an)*5,cy+sin(an)*5,cx+cos(an)*120,cy+sin(an)*120,WHITE);
  for(int i=0;i<NUM_CIRCLES;i++){circleRadii[i]+=sp;if(circleRadii[i]>120)circleRadii[i]=1;if(circleRadii[i]>2)display.drawCircle(cx,cy,circleRadii[i],WHITE);}
}
void drawEQ(Effect c, bool a) {
  int bw=SCREEN_WIDTH/NUM_BARS;
  if(frameCount%3==0)for(int i=0;i<NUM_BARS;i++){ if(a){ if(c==EFFECT_ZOOM_IN)targetHeights[i]=random(15,35); else if(c==EFFECT_SHAKE)targetHeights[i]=random(10,25); else targetHeights[i]=random(5,15);} else targetHeights[i]=random(1,6);}
  for(int i=0;i<NUM_BARS;i++){ if(barHeights[i]<targetHeights[i])barHeights[i]+=4; else if(barHeights[i]>targetHeights[i])barHeights[i]-=3; if(barHeights[i]<1)barHeights[i]=1; display.fillRect(i*bw+1,SCREEN_HEIGHT-barHeights[i],bw-1,barHeights[i],WHITE);}
}
void drawStars() {
  wavePhase+=0.18;
  for(int x=0;x<128;x+=2)display.drawPixel(x,58+(int)(4*sin(x*0.09+wavePhase)), WHITE);
  for(int i=0;i<30;i++){starX[i]-=starS[i];if(starX[i]<0){starX[i]=127;starY[i]=random(50);}display.drawPixel(starX[i],starY[i], WHITE);}
}
void drawMatrix() {
  for(int i=0;i<16;i++){dropY[i]+=dropS[i];if(dropY[i]-dropL[i]>63){dropY[i]=random(-30,0);dropL[i]=random(6,18);}int y0=dropY[i]-dropL[i],y1=dropY[i];if(y1>63)y1=63;if(y0<0)y0=0;if(y1>y0)display.drawFastVLine(i*8+4,y0,y1-y0+1, WHITE);}
}
void drawBubbles() {
  pulsePhase+=0.15; display.drawCircle(64,32,8+(int)(3*sin(pulsePhase)), WHITE);
  for(int i=0;i<10;i++){bubY[i]-=bubS[i];if(bubY[i]<-8){bubY[i]=72;bubX[i]=random(4,124);}display.drawCircle(bubX[i],bubY[i],bubR[i], WHITE);}
}
void drawShockwave() {
  if(wave.active){display.drawCircle(64,32,wave.radius,WHITE);wave.radius+=10;if(wave.radius>140)wave.active=false;}
}
"""

def pick_file(patterns, label):
    files = []
    for p in patterns:
        files.extend(glob.glob(p))
    files = sorted(set(files))
    if not files:
        print(f"❌ No {label} file found! Put one in this folder.")
        sys.exit(1)
    if len(files) == 1:
        print(f"✅ Auto-picked {label}: {files[0]}")
        return files[0]
    print(f"\n📂 Pick your {label}:")
    for i, f in enumerate(files, 1):
        print(f"   [{i}] {f}")
    while True:
        try:
            c = int(input("   > ")) - 1
            if 0 <= c < len(files): return files[c]
        except ValueError: pass

def assign_effect(word, theme):
    wl = word.lower().rstrip(',.')
    if theme == 1:
        if wl in ['love','shape','body','baby']: return 'EFFECT_ZOOM_IN'
        if wl in ['crazy','dance','beat','fight']: return 'EFFECT_SHAKE'
        if len(word) >= 8: return 'EFFECT_POP'
        return 'EFFECT_NONE'
    if theme == 2:
        if wl in ['oh','i','love','you']: return 'EFFECT_FLOAT'
        if len(word) >= 8: return 'EFFECT_PULSE'
        return 'EFFECT_NONE'
    if theme == 3:
        if wl in ['no','not','never','stop']: return 'EFFECT_INVERT'
        if wl in ['crazy','beat','fight']: return 'EFFECT_SHAKE'
        if len(word) >= 8: return 'EFFECT_GLITCH'
        return 'EFFECT_NONE'
    if wl in ['love','dream','baby','heart']: return 'EFFECT_PULSE'
    if wl in ['oh','i','you']: return 'EFFECT_FLOAT'
    if len(word) >= 8: return 'EFFECT_SLOW_ZOOM'
    return 'EFFECT_NONE'

print("=" * 52)
print("   🎵 LYRICODE - ONE COMMAND PIPELINE")
print("=" * 52)

song_name = input("\n🎤 Song name for this project (subfolder): ").strip()
if not song_name: song_name = "my_song"
song_name = song_name.replace(" ", "_")
folder = os.path.join("songs", song_name)
os.makedirs(folder, exist_ok=True)

audio = pick_file(["*.mp3", "*.wav", "music/*.mp3", "music/*.wav"], "AUDIO")
lyrics = pick_file(["*.txt", "lyrics/*.txt"], "LYRICS")

with open(lyrics, 'r', encoding='utf-8') as f:
    lyrics_text = f.read()

# ── NON-ENGLISH CHECK -> FIRE MODE ──
lyrics_mode = True
if NON_ENGLISH.search(lyrics_text):
    lyrics_mode = False
    print("\n🌐 Non-English words detected -> 🔥 FIRE MODE (animation + fire, no lyrics)")

# ── TRIM LONG SONGS TO 90s ──
orig_sec = librosa.get_duration(path=audio)
trimmed = orig_sec > MAX_DURATION_SEC
work_audio = audio
total_sec = orig_sec
if trimmed:
    print(f"\n✂️ Song is {int(orig_sec)}s long - trimming audio to {MAX_DURATION_SEC}s")
    y, sr = librosa.load(audio, sr=None, duration=MAX_DURATION_SEC)
    work_audio = os.path.join(folder, "trimmed_audio.wav")
    sf.write(work_audio, y, sr)
    total_sec = MAX_DURATION_SEC

words = []
if lyrics_mode:
    # ── Cut lyrics to match 90s ──
    work_lyrics = lyrics
    if trimmed:
        budget = int(MAX_DURATION_SEC * 2.5)
        try:
            from faster_whisper import WhisperModel
            import torch
            dev = "cuda" if torch.cuda.is_available() else "cpu"
            wm = WhisperModel("base", device=dev, compute_type=("float16" if dev == "cuda" else "int8"))
            segs, _ = wm.transcribe(work_audio, language="en", vad_filter=True)
            cnt = sum(len((s.text or "").split()) for s in segs)
            if cnt > 10:
                budget = int(cnt * 1.2) + 10
            print(f"   🎤 Heard ~{cnt} words in first 90s -> lyric budget {budget}")
        except Exception as e:
            print(f"   ⚠️ Quick ASR skipped - using default budget {budget}")
        lwords = lyrics_text.split()
        if len(lwords) > budget:
            print(f"   ✂️ Cutting lyrics {len(lwords)} -> {budget} words")
            lwords = lwords[:budget]
        work_lyrics = os.path.join(folder, "trimmed_lyrics.txt")
        with open(work_lyrics, 'w', encoding='utf-8') as f:
            f.write(" ".join(lwords))

    # ── Clear cache + decode ──
    if os.path.exists("stems"):
        shutil.rmtree("stems", ignore_errors=True)
        print("\n🧹 Cleared old stems cache")
    print("\n[DECODE] Separating + aligning...")
    from core import SongDecoder
    dec = SongDecoder()
    decoded_path = os.path.join(folder, "decoded.json")
    dec.decode(work_audio, work_lyrics, decoded_path)

    # ── Refine ──
    print("\n[REFINE] Snapping to real vocal onsets...")
    with open(decoded_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    raw = data.get('words', data.get('words ', []))
    JUNK = {'tickets','sheeran','chroma','creator','drake','embed','st.','family','matters'}
    for w in raw:
        word = str(w.get('word', w.get('word ', '')))
        for q in ['"', '"', '"', '"', '`']:
            word = word.replace(q, '')
        word = word.strip().strip('()').strip()
        wl = word.lower().rstrip(',.')
        start = int(w.get('start_ms', w.get('start_ms ', 0)))
        end = int(w.get('end_ms', w.get('end_ms ', 0)))
        if not word or len(word) > 23: continue
        if word.startswith('[') or word.endswith(']'): continue
        if '$' in word or wl in JUNK or wl in ('mm','mmm'): continue
        if end <= start: end = start + 150
        words.append({'word': word, 'start': start/1000.0, 'end': end/1000.0})
    words.sort(key=lambda x: x['start'])

    vocal_hits = glob.glob(os.path.join("stems", "**", "vocals.wav"), recursive=True)
    onsets = []
    if vocal_hits:
        y, sr = librosa.load(max(vocal_hits, key=os.path.getmtime), sr=16000)
        o_env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=256)
        fr = librosa.onset.onset_detect(onset_envelope=o_env, sr=sr, hop_length=256, backtrack=True)
        onsets = librosa.frames_to_time(fr, sr=sr, hop_length=256)

    def snap(t):
        if len(onsets) == 0: return t
        i = np.searchsorted(onsets, t); best, bd = t, 0.35
        for j in (i-1, i):
            if 0 <= j < len(onsets):
                d = abs(float(onsets[j]) - t)
                if d < bd: bd, best = d, float(onsets[j])
        return best

    for w in words: w['start'] = snap(w['start'])
    for i in range(1, len(words)):
        if words[i]['start'] < words[i-1]['start'] + 0.06:
            words[i]['start'] = words[i-1]['start'] + 0.06
    for i in range(len(words)):
        dur = min(words[i+1]['start'] - words[i]['start'], 4.0) if i+1 < len(words) else max(words[i]['end'] - words[i]['start'], 0.8)
        words[i]['end'] = words[i]['start'] + max(dur, 0.25)

    if len(words) > MAX_WORDS:
        print(f"⚠️ Huge lyrics ({len(words)}). Keeping first {MAX_WORDS}.")
        words = words[:MAX_WORDS]

    if not words:
        print("❌ No usable words decoded - switching to 🔥 FIRE MODE")
        lyrics_mode = False
    else:
        refined_path = os.path.join(folder, "decoded_refined.json")
        with open(refined_path, 'w', encoding='utf-8') as f:
            json.dump({"song": song_name, "total_duration_ms": int(total_sec*1000),
                       "words": [{"word": w['word'], "start_ms": int(w['start']*1000), "end_ms": int(w['end']*1000)} for w in words]}, f, indent=2)
        print(f"✅ Refined {len(words)} words -> {refined_path}")

# ── Animation menu ──
if lyrics_mode:
    wpm = len(words) / (total_sec/60.0) if total_sec > 0 else 0
    rec = 3 if wpm >= 90 else (1 if wpm >= 60 else 2)
    vibe = "Fast/Rap" if wpm >= 90 else ("Pop/Energy" if wpm >= 60 else "Slow/Ballad")
    print(f"\n[ANALYZE] ~{int(wpm)} words/min -> {vibe} vibe\n")
else:
    rec = 3
    print("\n[ANALYZE] FIRE MODE - pick a backdrop for the fire\n")

combos = [
    (1, "🔥 ENERGY", "Tunnel + EQ Bars + Shockwaves"),
    (2, "🌊 CHILL ", "Stars + Wave"),
    (3, "⚡ GLITCH", "Matrix Rain + Shockwaves"),
    (4, "💫 DREAMY", "Bubbles + Pulse Rings"),
]
print("   Pick a background combo:")
for cid, cname, cdesc in combos:
    star = "  ⭐ RECOMMENDED" if cid == rec else ""
    print(f"   [{cid}] {cname} - {cdesc}{star}")
while True:
    try:
        theme = int(input("   > "))
        if 1 <= theme <= 4: break
    except ValueError: pass

# ── Generate .ino ──
if lyrics_mode:
    lines = []
    for w in words:
        dur = int((w['end'] - w['start']) * 1000)
        lines.append(f'  {{ {int(w["start"]*1000)}, {dur}, "{w["word"]}", {assign_effect(w["word"], theme)}, 2 }},')
    has = 1
    boot_line = "FIRST WORD."
    total_ms = int(words[-1]['end'] * 1000) + 3000
else:
    lines = ['  { 0, 1, "", EFFECT_NONE, 2 },']
    has = 0
    boot_line = "PLAY (FIRE MODE)"
    total_ms = int(total_sec * 1000) + 3000

cpp = CPP_TEMPLATE.replace('__THEME__', str(theme))
cpp = cpp.replace('__HAS_LYRICS__', str(has))
cpp = cpp.replace('__BOOT_LINE__', boot_line)
cpp = cpp.replace('__LYRICS_DATA__', '\n'.join(lines))
cpp = cpp.replace('__TOTAL_DURATION__', str(total_ms))
cpp = cpp.replace('__SONG_NAME__', song_name)

ino_path = os.path.join(folder, f"lyricode_{song_name}.ino")
with open(ino_path, 'w', encoding='utf-8') as f:
    f.write(cpp)

print("\n" + "=" * 52)
print("   ✅ ALL DONE!")
print("=" * 52)
if lyrics_mode:
    print(f"   📁 Decoded : {os.path.join(folder, 'decoded.json')}")
    print(f"   📁 Refined : {os.path.join(folder, 'decoded_refined.json')}")
else:
    print("   🔥 FIRE MODE: no lyrics on screen, fire + animation only")
print(f"   📁 ESP32   : {ino_path}")
print(f"\n   Flash '{ino_path}' and enjoy! 🚀")
