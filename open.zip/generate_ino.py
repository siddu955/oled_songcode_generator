import json
import os
import glob

# ─── AUTO-FIND ANY JSON FILE ───
def find_json_file():
    json_files = []
    for path in ["*.json", "output/*.json", "lyrics/*.json"]:
        json_files.extend(glob.glob(path))
    if not json_files:
        print("❌ No JSON file found! Put your decoded .json in this folder.")
        return None
    if len(json_files) == 1:
        print(f"✅ Found: {json_files[0]}")
        return json_files[0]
    print(f"\n📂 Found {len(json_files)} JSON files:")
    for i, f in enumerate(json_files, 1):
        print(f"   [{i}] {f}")
    while True:
        try:
            c = int(input("   Pick a number: ")) - 1
            if 0 <= c < len(json_files):
                return json_files[c]
        except ValueError:
            pass

input_file = find_json_file()
if not input_file:
    exit()

with open(input_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

raw = data.get('words', data.get('words ', []))
total_duration = data.get('total_duration_ms', data.get('total_duration_ms ', 233743))
song_name = data.get('song', data.get('song ', 'song')).strip().replace('.mp3', '')

# ─── STEP 1: CLEAN JUNK (tags, ads, quotes, brackets) ───
JUNK_EXACT = {'tickets','sheeran','chroma','tyler,','creator','drake','embed','st.','darling,','matters','family'}
JUNK_LOWCONF = {'see','ed','live','get','as','you','might','also','like','the'}
clean = []
removed = 0
for w in raw:
    word = w.get('word', w.get('word ', ''))
    start = int(w.get('start_ms', w.get('start_ms ', 0)))
    end = int(w.get('end_ms', w.get('end_ms ', 0)))
    conf = float(w.get('confidence', w.get('confidence ', 0.5)))

    # strip quotes + brackets
    for q in ['"', '"', '"', '"', '`']:
        word = word.replace(q, '')
    word = word.strip().strip('()').strip()
    wl = word.lower().rstrip(',.')

    skip = False
    if not word or len(word) > 23: skip = True
    elif word.startswith('[') or word.endswith(']'): skip = True
    elif '$' in word: skip = True
    elif wl in JUNK_EXACT: skip = True
    elif wl in JUNK_LOWCONF and conf < 0.5: skip = True
    elif wl in ('mm', 'mmm'): skip = True

    if skip:
        removed += 1
        continue
    if end <= start:
        end = start + 150
    clean.append({'word': word, 'start': start, 'end': end})

# ─── STEP 2: SORT + RELATIVE TIME (sync = press BOOT on first word) ───
clean.sort(key=lambda x: x['start'])
t0 = clean[0]['start']
for w in clean:
    w['start'] -= t0
    w['end'] -= t0

# ─── STEP 3: HOLD EACH WORD UNTIL THE NEXT ONE STARTS ───
# Fixes "singer sings slow but display switches fast"
for i in range(len(clean)):
    own = clean[i]['end'] - clean[i]['start']
    if i + 1 < len(clean):
        gap = clean[i+1]['start'] - clean[i]['start']
        dur = min(gap, 4000)          # switch exactly when next word starts
    else:
        dur = max(own, 800)           # last word holds 0.8s
    if dur < 250:
        dur = 250                     # never flash shorter than 0.25s
    clean[i]['end'] = clean[i]['start'] + dur

print(f"🧹 Removed {removed} junk words. Kept {len(clean)} words.")

cpp_template = """
/*
 * LYRICODE :: __SONG_NAME__ (FINAL v6)
 *
 * HOW TO SYNC:
 *  1. Play the EXACT SAME mp3 you decoded (not Spotify/YouTube!)
 *  2. Press BOOT exactly when you HEAR the first word.
 *  3. If it drifts during the song:
 *       QUICK TAP  = words 0.5s LATER  (display running ahead)
 *       HOLD 0.5s  = words 0.5s EARLIER (display lagging behind)
 *
 * Wiring: VCC->3.3V | GND->GND | SCL->GPIO22 | SDA->GPIO21
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SYNC_BUTTON_PIN 0
#define SYNC_OFFSET_MS 0

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define NUM_CIRCLES 5
float circleRadii[NUM_CIRCLES];
#define NUM_BARS 12
int barHeights[NUM_BARS];
int targetHeights[NUM_BARS];

struct Shockwave { float radius; bool active; } wave;
int lastLyricIdx = -1;
unsigned long frameCount = 0;

enum Effect {
  EFFECT_NONE = 0, EFFECT_POP, EFFECT_SHAKE, EFFECT_INVERT,
  EFFECT_GLITCH, EFFECT_ZOOM_IN, EFFECT_FLOAT, EFFECT_PULSE, EFFECT_SLOW_ZOOM
};

struct Lyric {
  unsigned long startMs;
  unsigned long durationMs;
  char word[24];
  Effect effect;
  uint8_t size;
};

const Lyric lyrics[] PROGMEM = {
__LYRICS_DATA__
};
const int numLyrics = sizeof(lyrics) / sizeof(Lyric);
unsigned long TOTAL_LOOP_TIME = __TOTAL_DURATION__;

unsigned long startTime = 0;
bool synced = false;
int lyricSearchStart = 0;
long syncOffset = SYNC_OFFSET_MS;

// ─── Live nudge button (TAP = later, HOLD = earlier) ───
bool btnWas = false;
unsigned long btnDownAt = 0;

void handleNudge() {
  bool pressed = digitalRead(SYNC_BUTTON_PIN) == LOW;
  if (pressed && !btnWas) {
    btnWas = true;
    btnDownAt = millis();
  } else if (!pressed && btnWas) {
    btnWas = false;
    unsigned long held = millis() - btnDownAt;
    if (held < 300) {
      syncOffset -= 500;
      Serial.println("Nudge: -500ms (later)");
    } else {
      syncOffset += 500;
      Serial.println("Nudge: +500ms (earlier)");
    }
  }
}

int findCurrentLyric(unsigned long now) {
  for (int i = lyricSearchStart; i < numLyrics; i++) {
    Lyric l;
    memcpy_P(&l, &lyrics[i], sizeof(Lyric));
    if (now >= l.startMs && now <= (l.startMs + l.durationMs)) {
      lyricSearchStart = i;
      return i;
    }
    if (now > l.startMs + l.durationMs) lyricSearchStart = i + 1;
  }
  return -1;
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(800000);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) for (;;);

  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextWrap(false);

  for (int i = 0; i < NUM_CIRCLES; i++) circleRadii[i] = i * (100.0 / NUM_CIRCLES);
  for (int i = 0; i < NUM_BARS; i++) { barHeights[i] = 0; targetHeights[i] = 0; }
  wave.active = false;

  pinMode(SYNC_BUTTON_PIN, INPUT_PULLUP);

  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(5, 8);  display.print("__SONG_NAME__");
  display.setCursor(5, 20); display.print("PLAY SAME MP3,");
  display.setCursor(5, 30); display.print("PRESS BOOT ON");
  display.setCursor(5, 40); display.print("FIRST WORD.");
  display.setCursor(5, 52); display.print("TAP/HOLD=NUDGE");
  display.display();

  while (digitalRead(SYNC_BUTTON_PIN) == HIGH) delay(10);
  delay(50);
  while (digitalRead(SYNC_BUTTON_PIN) == LOW) delay(10);

  startTime = millis();
  synced = true;
  btnWas = false;
  Serial.println("LYRICODE: Synced at first word!");
}

void loop() {
  if (!synced) return;

  handleNudge();

  long nowL = (long)(millis() - startTime) + syncOffset;
  if (nowL < 0) nowL = 0;
  unsigned long now = (unsigned long)nowL;
  frameCount++;

  if (now > TOTAL_LOOP_TIME) {
    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(20, 24);
    display.print("THE END");
    display.display();
    delay(100);
    return;
  }

  display.clearDisplay();
  display.setTextSize(1);

  int currentLyricIdx = findCurrentLyric(now);

  Effect currentEffect = EFFECT_NONE;
  bool lyricActive = false;
  float progress = 0.0;
  bool invertScreen = false;

  if (currentLyricIdx != -1) {
    lyricActive = true;
    Lyric l;
    memcpy_P(&l, &lyrics[currentLyricIdx], sizeof(Lyric));
    currentEffect = l.effect;
    progress = (now - l.startMs) / (float)l.durationMs;

    if (currentLyricIdx != lastLyricIdx) {
      if (l.effect == EFFECT_POP || l.effect == EFFECT_INVERT ||
          l.effect == EFFECT_ZOOM_IN || l.effect == EFFECT_SHAKE) {
        wave.active = true;
        wave.radius = 5.0;
      }
      lastLyricIdx = currentLyricIdx;
    }
  } else {
    lastLyricIdx = -1;
  }

  if (frameCount % 2 == 0) drawTunnel(currentEffect, lyricActive);
  drawShockwave();
  drawEQ(currentEffect, lyricActive);

  if (currentLyricIdx != -1) {
    Lyric l;
    memcpy_P(&l, &lyrics[currentLyricIdx], sizeof(Lyric));

    int textSize = l.size;
    int offsetX = 0, offsetY = 0;

    if (l.effect == EFFECT_POP) {
      if (progress < 0.15) textSize = l.size + 1;
    } else if (l.effect == EFFECT_SHAKE) {
      offsetX = random(-1, 2); offsetY = random(-1, 2);
    } else if (l.effect == EFFECT_INVERT) {
      invertScreen = true;
      if (random(10) > 5) { offsetX = random(-2, 3); offsetY = random(-2, 3); }
    } else if (l.effect == EFFECT_GLITCH) {
      if (random(10) > 6) {
        offsetX = random(-6, 6);
        display.fillRect(0, random(SCREEN_HEIGHT), SCREEN_WIDTH, random(2, 8), WHITE);
      }
      if (random(10) > 8) invertScreen = true;
    } else if (l.effect == EFFECT_ZOOM_IN) {
      if (progress < 0.05) textSize = l.size > 1 ? l.size - 1 : 1;
      else if (progress < 0.1) textSize = l.size;
      else textSize = l.size + 1;
      if (progress > 0.4) { offsetX = random(-4, 5); offsetY = random(-4, 5); }
      if (progress > 0.3 && random(10) > 7) invertScreen = true;
    } else if (l.effect == EFFECT_FLOAT) {
      offsetY = -sin(progress * 3.14159) * 6 + random(-1, 2);
      offsetX = random(-1, 2);
    } else if (l.effect == EFFECT_PULSE) {
      if ((progress > 0.1 && progress < 0.25) || (progress > 0.6 && progress < 0.75)) textSize = l.size + 1;
      offsetX = random(-1, 2); offsetY = random(-1, 2);
    } else if (l.effect == EFFECT_SLOW_ZOOM) {
      offsetY = -(progress * 5) + random(-1, 2);
      offsetX = random(-1, 2);
      if (progress > 0.5) textSize = l.size + 1;
    }

    display.setTextSize(textSize);
    int16_t x1, y1;
    uint16_t w, h;
    display.getTextBounds(l.word, 0, 0, &x1, &y1, &w, &h);

    if (w > SCREEN_WIDTH) {
      textSize = 2; display.setTextSize(2);
      display.getTextBounds(l.word, 0, 0, &x1, &y1, &w, &h);
    }
    if (w > SCREEN_WIDTH) {
      textSize = 1; display.setTextSize(1);
      display.getTextBounds(l.word, 0, 0, &x1, &y1, &w, &h);
    }

    int drawX = (SCREEN_WIDTH - w) / 2 + offsetX;
    int drawY = (SCREEN_HEIGHT - h) / 2 + offsetY - 5;

    int boxX = drawX - 6;
    int boxY = drawY - 5;
    int boxW = w + 12;
    int boxH = h + 10;

    if (boxX < 0) { boxW += boxX; boxX = 0; }
    if (boxX + boxW > SCREEN_WIDTH) { boxW = SCREEN_WIDTH - boxX; }

    display.fillRoundRect(boxX, boxY, boxW, boxH, 3, BLACK);
    display.drawRoundRect(boxX, boxY, boxW, boxH, 3, WHITE);

    if (l.effect == EFFECT_GLITCH && random(10) > 8) {
      display.setTextColor(BLACK, WHITE);
      display.fillRoundRect(drawX - 4, drawY - 3, w + 8, h + 6, 2, WHITE);
    } else {
      display.setTextColor(WHITE);
    }

    display.setCursor(drawX, drawY);
    display.print(l.word);
  }

  display.invertDisplay(invertScreen);
  display.display();
  delay(5);
}

void drawTunnel(Effect currentEffect, bool lyricActive) {
  float speed = 1.0;
  if (currentEffect == EFFECT_ZOOM_IN) speed = 8.0;
  else if (currentEffect == EFFECT_SHAKE || currentEffect == EFFECT_GLITCH) speed = 4.0;
  else if (!lyricActive) speed = 0.5;

  int centerX = SCREEN_WIDTH / 2;
  int centerY = SCREEN_HEIGHT / 2;

  if (currentEffect == EFFECT_SHAKE || currentEffect == EFFECT_ZOOM_IN) {
    centerX += random(-3, 4); centerY += random(-3, 4);
  }

  for (float angle = 0; angle < 2 * PI; angle += PI / 2) {
    display.drawLine(centerX + cos(angle) * 5, centerY + sin(angle) * 5,
                     centerX + cos(angle) * 120, centerY + sin(angle) * 120, WHITE);
  }

  for (int i = 0; i < NUM_CIRCLES; i++) {
    circleRadii[i] += speed;
    if (circleRadii[i] > 120) circleRadii[i] = 1;
    if (circleRadii[i] > 2) display.drawCircle(centerX, centerY, circleRadii[i], WHITE);
  }
}

void drawEQ(Effect currentEffect, bool lyricActive) {
  int barWidth = SCREEN_WIDTH / NUM_BARS;
  if (frameCount % 3 == 0) {
    for (int i = 0; i < NUM_BARS; i++) {
      if (lyricActive) {
        if (currentEffect == EFFECT_ZOOM_IN) targetHeights[i] = random(15, 35);
        else if (currentEffect == EFFECT_SHAKE) targetHeights[i] = random(10, 25);
        else targetHeights[i] = random(5, 15);
      } else {
        targetHeights[i] = random(1, 6);
      }
    }
  }
  for (int i = 0; i < NUM_BARS; i++) {
    if (barHeights[i] < targetHeights[i]) barHeights[i] += 4;
    else if (barHeights[i] > targetHeights[i]) barHeights[i] -= 3;
    if (barHeights[i] < 1) barHeights[i] = 1;
    display.fillRect(i * barWidth + 1, SCREEN_HEIGHT - barHeights[i], barWidth - 1, barHeights[i], WHITE);
  }
}

void drawShockwave() {
  if (wave.active) {
    display.drawCircle(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, wave.radius, WHITE);
    wave.radius += 10.0;
    if (wave.radius > 140) wave.active = false;
  }
}
"""

# ─── STEP 4: EFFECTS + C++ DATA ───
lyrics_lines = []
for w in clean:
    word = w['word']
    wl = word.lower().rstrip(',.')

    if wl in ['love', 'shape', 'body', 'magnet', 'baby']:
        effect = 'EFFECT_ZOOM_IN'
    elif wl in ['oh', 'i']:
        effect = 'EFFECT_PULSE'
    elif wl in ['crazy', 'dance', 'jukebox', 'radio', 'taxi']:
        effect = 'EFFECT_SHAKE'
    elif wl in ['night', 'room', 'new', 'now']:
        effect = 'EFFECT_INVERT'
    elif wl in ['singin', 'doin', 'drinkin', 'discoverin', 'somethin', 'fallin', 'goin']:
        effect = 'EFFECT_GLITCH'
    elif wl in ['me', 'you', 'lead']:
        effect = 'EFFECT_FLOAT'
    elif len(word) >= 8:
        effect = 'EFFECT_POP'
    else:
        effect = 'EFFECT_NONE'

    dur = w['end'] - w['start']
    lyrics_lines.append(f'  {{ {w["start"]}, {dur}, "{word}", {effect}, 2 }},')

total = clean[-1]['end'] + 3000

final_code = cpp_template.replace('__LYRICS_DATA__', '\n'.join(lyrics_lines))
final_code = final_code.replace('__TOTAL_DURATION__', str(total))
final_code = final_code.replace('__SONG_NAME__', song_name)

os.makedirs('output', exist_ok=True)
output_file = f'output/lyricode_{song_name.replace(" ", "_")}.ino'
with open(output_file, 'w', encoding='utf-8') as f:
    f.write(final_code)

print(f"\n✅ Generated: {output_file}")
print(f"   Words: {len(lyrics_lines)} | Duration: {total}ms")
print(f"\n🎯 SYNC: play the SAME mp3, press BOOT on the FIRST WORD")
print(f"🎛  Drift? TAP = 0.5s later | HOLD = 0.5s earlier")
