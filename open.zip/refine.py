import json
import os
import glob
import librosa
import numpy as np

# ─── Find the decoded JSON (not refined yet) ───
def find_json():
    cands = []
    for p in ["*.json", "output/*.json"]:
        cands += glob.glob(p)
    cands = [c for c in cands if 'refined' not in os.path.basename(c).lower()]
    if not cands:
        print("❌ No decoded JSON found. Run main.py first!")
        return None
    if len(cands) == 1:
        return cands[0]
    print("📂 Multiple JSONs found:")
    for i, f in enumerate(cands, 1):
        print(f"   [{i}] {f}")
    while True:
        try:
            c = int(input("   Pick: ")) - 1
            if 0 <= c < len(cands):
                return cands[c]
        except ValueError:
            pass

# ─── Find the separated vocal stem ───
def find_vocals():
    hits = glob.glob(os.path.join("stems", "**", "vocals.wav"), recursive=True)
    if hits:
        return max(hits, key=os.path.getmtime)
    return None

json_path = find_json()
vocal_path = find_vocals()
if not json_path or not vocal_path:
    print("❌ Need both decoded JSON and stems/**/vocals.wav (run main.py first)")
    exit()

print(f" Refining: {json_path} against {vocal_path}")

with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

raw = data.get('words', data.get('words ', []))
total_duration = data.get('total_duration_ms', data.get('total_duration_ms ', 233743))
song_name = data.get('song', data.get('song ', 'song')).strip().replace('.mp3', '')

# ─── Clean junk (same rules as generator) ───
JUNK_EXACT = {'tickets','sheeran','chroma','tyler,','creator','drake','embed','st.','darling,','matters','family'}
JUNK_LOWCONF = {'see','ed','live','get','as','you','might','also','like','the'}
words = []
for w in raw:
    word = w.get('word', w.get('word ', ''))
    start = int(w.get('start_ms', w.get('start_ms ', 0)))
    end = int(w.get('end_ms', w.get('end_ms ', 0)))
    conf = float(w.get('confidence', w.get('confidence ', 0.5)))
    for q in ['"', '"', '"', '"', '`']:
        word = word.replace(q, '')
    word = word.strip().strip('()').strip()
    wl = word.lower().rstrip(',.')
    skip = False
    if not word or len(word) > 23: skip = True
    elif word.startswith('[') or word.endswith(']'): skip = True
    elif '$' in word: skip = True
    elif wl in JUNK_EXACT: skip = True
    elif wl in JUNK_LOWCONF and conf < 0.5: skip = True
    elif wl in ('mm', 'mmm'): skip = True
    if skip: continue
    if end <= start: end = start + 150
    words.append({'word': word, 'start': start / 1000.0, 'end': end / 1000.0, 'conf': conf})

words.sort(key=lambda x: x['start'])

# ─── Load vocal stem + detect REAL vocal onsets ───
y, sr = librosa.load(vocal_path, sr=16000)
o_env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=256)
frames = librosa.onset.onset_detect(onset_envelope=o_env, sr=sr, hop_length=256, backtrack=True)
onsets = librosa.frames_to_time(frames, sr=sr, hop_length=256)
print(f"🎵 Detected {len(onsets)} real vocal onsets in the audio")

def snap(t):
    """Snap a timestamp to the nearest real vocal onset (±350ms)"""
    if len(onsets) == 0:
        return t
    i = np.searchsorted(onsets, t)
    best, bd = t, 0.35
    for j in (i - 1, i):
        if 0 <= j < len(onsets):
            d = abs(float(onsets[j]) - t)
            if d < bd:
                bd, best = d, float(onsets[j])
    return best

# ─── Snap every word start to a real onset ───
snapped_count = 0
for w in words:
    s = snap(w['start'])
    if abs(s - w['start']) > 0.001:
        snapped_count += 1
    w['start'] = s

# Enforce strictly increasing starts (min 60ms apart)
for i in range(1, len(words)):
    if words[i]['start'] < words[i-1]['start'] + 0.06:
        words[i]['start'] = words[i-1]['start'] + 0.06

# ─── Ends = next word's REAL start (hold through stretches & pauses) ───
for i in range(len(words)):
    if i + 1 < len(words):
        dur = min(words[i+1]['start'] - words[i]['start'], 4.0)
    else:
        dur = max(words[i]['end'] - words[i]['start'], 0.8)
    if dur < 0.25:
        dur = 0.25
    words[i]['end'] = words[i]['start'] + dur

# ─── Save refined JSON ───
os.makedirs('output', exist_ok=True)
out = {
    "song": song_name,
    "total_duration_ms": total_duration,
    "words": [
        {"word": w['word'],
         "start_ms": int(w['start'] * 1000),
         "end_ms": int(w['end'] * 1000),
         "confidence": round(w['conf'], 3)}
        for w in words
    ]
}
with open('output/decoded_refined.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)

print(f"✅ Snapped {snapped_count}/{len(words)} words to real vocal onsets")
print(f"✅ Saved output/decoded_refined.json")
print(f"\nNext: python generate_ino.py  (it will auto-pick the refined file)")
